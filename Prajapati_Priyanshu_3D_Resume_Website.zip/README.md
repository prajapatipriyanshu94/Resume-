# Prajapati Priyanshu — 3D Resume

An interactive 3D resume website built with pure HTML, CSS and JavaScript.

## Run locally

Open `index.html` in a browser, or use VS Code Live Server.

## Deploy on GitHub + Vercel

1. Create a GitHub repository, for example `priyanshu-3d-resume`.
2. Upload `index.html`, `style.css`, `script.js`, and `README.md`.
3. On Vercel, import the GitHub repository.
4. Framework preset: **Other**.
5. Build command: leave empty.
6. Output directory: `.`
7. Deploy.

No Node.js or build step is required.
